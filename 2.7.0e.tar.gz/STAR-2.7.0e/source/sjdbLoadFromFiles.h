#ifndef CODE_sjdbLoadFromFiles
#define CODE_sjdbLoadFromFiles

#include <fstream>
#include "SjdbClass.h"
#include "Parameters.h"

void sjdbLoadFromFiles(Parameters &P, SjdbClass &sjdbLoci);

#endif
